#ifndef __ASM_R8A7779_H__
#define __ASM_R8A7779_H__

extern void r8a7779_pm_init(void);

extern const struct smp_operations r8a7779_smp_ops;

#endif /* __ASM_R8A7779_H__ */
