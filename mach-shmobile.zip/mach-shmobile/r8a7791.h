#ifndef __ASM_R8A7791_H__
#define __ASM_R8A7791_H__

extern const struct smp_operations r8a7791_smp_ops;

#endif /* __ASM_R8A7791_H__ */
