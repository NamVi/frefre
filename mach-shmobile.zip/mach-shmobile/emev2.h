#ifndef __ASM_EMEV2_H__
#define __ASM_EMEV2_H__

extern const struct smp_operations emev2_smp_ops;

#endif /* __ASM_EMEV2_H__ */
